﻿using DataAccess;
using Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FakeValues : ControllerBase
    {
        public FakeValues(Asp2023DbContext context)
        {
            Context = context;
        }
        private Asp2023DbContext Context { get; }


        // POST api/<FakeValues>
        /// <summary>
        ///  GENERISANJE INICIJALNIH PODATAKA 
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///  
        ///
        ///     POST /api/FakeValues
        ///     {
        ///          
        ///         
        ///     }
        ///      
        ///     
        ///
        /// </remarks>
        /// <response code="201">Insert</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Unexpected server error.</response>
        /// 
        [HttpPost]

        public IActionResult Post()
        {
/*
             Context.AllUserUseCases.AsNoTracking().FirstOrDefault();
             Context.ArticleUserEmotions.AsNoTracking().FirstOrDefault();*/

            var roles = new List<Role>
            {
                new Role
                {
                    NameRole= "Korisnik"     //Obavezno ovaj naziv 
                },
                new Role
                {
                    NameRole= "Administrator"  //Obavezno ovaj naziv*
                }
            };

            var companies = new List<Company>
            {
                new Company
                {
                    NameCompany="Kompanija 1",
                    Discount= 5,
                },
                new Company
                {
                    NameCompany="Kompanija 2",
                    Discount= 3,
                },
            };

            var countries = new List<Country>
            {
                new Country
                {
                    NameCountry="Srbija1",
                },
                new Country
                {
                    NameCountry="Bosna1",
                },
                new Country
                {
                    NameCountry="Crna Gora1",
                },
            };

            var townships = new List<Township>
            {
                new Township
                {
                    NameTownship="Palilula1",
                    Country=countries.ElementAt(0)
                },
                new Township
                {
                    NameTownship="Obrenovac1",
                    Country=countries.ElementAt(0)
                },
                new Township
                {
                    NameTownship="Opstina Bosna1",
                    Country=countries.ElementAt(1)
                }
            };

            var stickers = new List<Sticker>
            {
                new Sticker
                {
                    NameSticker="Smesan Stiker1",
                    StickerPath="Path1"
                },
                new Sticker
                {
                    NameSticker="Tuzan Stiker1",
                    StickerPath="Path1"
                }
            };

            var catDimension = new List<CategoryDimension>
            {
                new CategoryDimension
                {
                    Dimension="full screen",
                    Price=50,
                },
                new CategoryDimension
                {
                    Dimension="half screen",
                    Price=10,
                },
            };

            var catComments = new List<CategoryComment>
            {
                new CategoryComment
                {
                    NameCategoryComment="komentar 16:9",
                    Price=50,
                    StylePath="Path Comment 1"
                },
                new CategoryComment
                {
                    NameCategoryComment="komentar 1:2",
                    Price=10,
                    StylePath="Path Comment 2"
                },
            };

            var catDesignArt = new List<CategoryDesignArticle>
            {
                new CategoryDesignArticle
                {
                    NameDesign="Srednji Dizajn",
                    Price=50,
                    DesignPath="Path 1"
                },
                new CategoryDesignArticle
                {
                    NameDesign="Visoki Dizajn",
                    Price=10,
                    DesignPath="Path 2"
                },
            };

            var noRegUser = new List<NonRegisteredUser>
            {
                new NonRegisteredUser
                {
                    FirstName="Mika",
                    LastName ="Mikic",
                    Email="mikaanonym@gmail.com",
                    PhoneNumber="100000",
                },
                new NonRegisteredUser
                {
                    FirstName="Pera",
                    LastName ="Peric",
                    Email="peraaanonym@gmail.com",
                    PhoneNumber="100000",
                }
            };


            var users = new List<User>
            {
                new User
                {
                    FirstName="Lazar",
                    LastName="Galic",
                    Email="galic.lazar@gmail.com",
                    Password="$2a$11$.3RTp6plepU23UYgtQBv1uGYx/cQhCjhdrbiUMaB07tOOF1Xg3FS.",
                    IdentityNumber="12412412",
                    PhoneNumber="1412121",
                    Role=roles.ElementAt(1)
                },
                new User
                {
                    FirstName="Mirko",
                    LastName="Mirkovic",
                    Email="mirkovicc@gmail.com",
                    Password="$2a$11$.3RTp6plepU23UYgtQBv1uGYx/cQhCjhdrbiUMaB07tOOF1Xg3FS.",
                    IdentityNumber="12412412",
                    PhoneNumber="1412121",
                    Role=roles.ElementAt(0)
                },
                new User
                {
                    FirstName="Milenko",
                    LastName="Mirkovic",
                    Email="milenkomirkovicc@gmail.com",
                    Password="$2a$11$.3RTp6plepU23UYgtQBv1uGYx/cQhCjhdrbiUMaB07tOOF1Xg3FS.",
                    IdentityNumber="12412412",
                    PhoneNumber="1412121",
                    Role=roles.ElementAt(0)
                },
            };





            var regUserRoles = new List<int> { 9, 10, 11, 14, 16, 19, 22, 26,   20, 21, 23, 24, 29, 28    };
            var adminUserRoles = new List<int> { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29 }; 
            var usecaseRoles = new List<UseCaseRole>();

            foreach(var r in regUserRoles)
            {
                usecaseRoles.Add(new UseCaseRole
                {
                    Role = roles.ElementAt(0),
                    UseCaseId= r
                });
            }
            foreach (var a in adminUserRoles)
            {
                usecaseRoles.Add(new UseCaseRole
                {
                    Role = roles.ElementAt(1),
                    UseCaseId = a
                });
            }



            var articles = new List<Article>
            {
                new Article
                {
                    NameArticle="Moj Prvi Artikal",
                    Description="Opis dugacki",
                    AdditionalDescription="Dasdasdas",
                    Quote="Ko rano rani",
                    Beggin=DateTime.Now.AddDays(-20),
                    End=DateTime.Now.AddDays(20),
                    User=users.ElementAt(0),
                    MainPicturePath="profilna 1",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="Dasdsadas",
                    Township=townships.ElementAt(0),
                },
                new Article
                {
                    NameArticle="Moj Drugi Artikal",
                    Description="Opis dugacki2",
                    AdditionalDescription="Dasdasdas2",
                    Quote="Ko rano rani2",
                    Beggin=DateTime.Now.AddMonths(-20),
                    End=DateTime.Now.AddDays(50),
                    User=users.ElementAt(0),
                    MainPicturePath="profilna 2",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="Dasdsadasasdasda",
                    Township=townships.ElementAt(1),
                },
                new Article
                {
                    NameArticle="Aaaaaaa Artikal",
                    Description="Opis",
                    AdditionalDescription="Dasdasdasasda",
                    Quote="Nesto pametno al nije obavezno polje svakako",
                    Beggin=DateTime.Now.AddMonths(-1),
                    End=DateTime.Now.AddDays(-5),
                    User=users.ElementAt(1),
                    MainPicturePath="profilna 2",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="AAAAAAAAAAA",
                    Township=townships.ElementAt(1),
                },
                new Article
                {
                    NameArticle="Bbbbbbbbbb Artikal",
                    Description="Opissss",
                    AdditionalDescription="Dasdasdasasda",
                    Quote="Nesto pametno al nije obavezno polje svakako",
                    Beggin=DateTime.Now.AddMonths(-11),
                    End=DateTime.Now.AddDays(-15),
                    User=users.ElementAt(2),
                    MainPicturePath="profilna ",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="CCCCCCCCCCCC",
                    Township=townships.ElementAt(0),
                },
                new Article
                {
                    NameArticle="Dasdasdasdsadsad Postt",
                    Description="Dasdsadasasdsadadad",
                    AdditionalDescription="Dasdasdasasda",
                    Quote="Nesto pametno al nije obavezno polje svakako",
                    Beggin=DateTime.Now.AddMonths(-11),
                    End=DateTime.Now.AddDays(-15),
                    User=users.ElementAt(2),
                    MainPicturePath="profilna ",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="CCCCCCCCCCCC",
                    Township=townships.ElementAt(0),
                },
                new Article
                {
                    NameArticle="Dasdasdasdsadsad Postt",
                    Description="Dasdsadasasdsadadad",
                    AdditionalDescription="Dasdasdasasda",
                    Quote="Nesto pametno al nije obavezno polje svakako",
                    Beggin=DateTime.Now.AddMonths(-11),
                    End=DateTime.Now.AddDays(-15),
                    //User=users.ElementAt(2),
                    NonRegisteredUser=noRegUser.ElementAt(0),
                    MainPicturePath="profilna ",
                    CategoryDimension=catDimension.ElementAt(0),
                    CategoryDesignArticle=catDesignArt.ElementAt(0),
                    MainContent="CCCCCCCCCCCC",
                    Township=townships.ElementAt(0),
                },
            };




            var allUsersUseCase = new List<AllUserUseCase>();

            foreach (var r in regUserRoles)
            {
                allUsersUseCase.Add(new AllUserUseCase
                {
                    User = users.ElementAt(1),
                    UseCaseId = r
                });

            }

            foreach (var r in regUserRoles)
            {
                allUsersUseCase.Add(new AllUserUseCase
                {
                    User = users.ElementAt(2),
                    UseCaseId = r
                });
            }


            foreach (var a in adminUserRoles)
            {
                allUsersUseCase.Add(new AllUserUseCase
                {
                    User = users.ElementAt(0),
                    UseCaseId = a
                });
            }



            var emotions = new List<Emotion>
            {
                new Emotion
                {
                    NameEmotion="Funny and lol",
                    Price = 100,
                    ImagePath="Pathh funny"
                },
                new Emotion
                {
                    NameEmotion = "Love",
                    Price = 200,
                    ImagePath="Pathh love"
                },
                new Emotion
                {
                    NameEmotion = "Scary",
                    Price = 150,
                    ImagePath="Pathh scary"
                }
            };



            var articleImages = new List<ArticleImage>()
            {
                new ArticleImage
                {
                    Article=articles.ElementAt(1),
                    ImagePath="putanjaa11",
                },
                new ArticleImage
                {
                    Article=articles.ElementAt(1),
                    ImagePath="putanjaa22",
                },
                new ArticleImage
                {
                    Article=articles.ElementAt(3),
                    ImagePath="putanjaaaaaaaaaa",
                },
            };



            var artUsEmot = new List<ArticleUserEmotion>
            {
                new ArticleUserEmotion
                {
                    Article=articles.ElementAt(0),
                    Emotion=emotions.ElementAt(0),
                    User=users.ElementAt(0)
                },
                new ArticleUserEmotion
                {
                    Article=articles.ElementAt(1),
                    Emotion=emotions.ElementAt(2),
                    User=users.ElementAt(2)
                },
                new ArticleUserEmotion
                {
                    Article=articles.ElementAt(4),
                    Emotion=emotions.ElementAt(1),
                    User=users.ElementAt(2)
                },


            };



            var usercomp = new List<UserCompany>()
             {
                 new UserCompany
                 {
                     User=users.ElementAt(0),
                     Company=companies.ElementAt(0)
                 }
             };


            var articleComments = new List<CommentArticle>()
            {
                new CommentArticle
                {
                    Content="Vauuu",
                    User=users.ElementAt(1),
                    Article=articles.ElementAt(0),
                    Sticker=stickers.ElementAt(0),
                    CategoryComment=catComments.ElementAt(0),
                    CategoryDimension=catDimension.ElementAt(0),
                },
                new CommentArticle
                {
                    Content="Komentaaar",
                    User=users.ElementAt(2),
                    Article=articles.ElementAt(0),
                    CategoryComment=catComments.ElementAt(0),
                    CategoryDimension=catDimension.ElementAt(1),
                },
               new CommentArticle
                {
                    Content="Komentaaar2",
                    User=users.ElementAt(2),
                    Article=articles.ElementAt(0),
                    CategoryComment=catComments.ElementAt(0),
                    CategoryDimension=catDimension.ElementAt(0),
                },
                new CommentArticle
                {
                    Content="Komentaaar3",
                    User=users.ElementAt(1),
                    Article=articles.ElementAt(0),
                    CategoryComment=catComments.ElementAt(0),
                    CategoryDimension=catDimension.ElementAt(0),
                },
                new CommentArticle
                {
                    Content="Komentaaarrasfdasdas dasdsadsada",
                    User=users.ElementAt(1),
                    Article=articles.ElementAt(3),
                    CategoryComment=catComments.ElementAt(0),
                    CategoryDimension=catDimension.ElementAt(0),
                },
            };

            articleComments.Add(new CommentArticle
            {
                ParentComment = articleComments.ElementAt(0),
                Content = "Podkomentari11",
                User = users.ElementAt(2),
                Article = articles.ElementAt(0),
                CategoryComment = catComments.ElementAt(0),
                CategoryDimension = catDimension.ElementAt(0),
            });


            articleComments.Add(new CommentArticle
            {
                ParentComment = articleComments.ElementAt(0),
                Content = "Podkomentari22",
                User = users.ElementAt(1),
                Article = articles.ElementAt(0),
                CategoryComment = catComments.ElementAt(1),
                CategoryDimension = catDimension.ElementAt(0),
            });

            articleComments.Add(new CommentArticle
            {
                ParentComment = articleComments.ElementAt(2),
                Content = "33333",
                User = users.ElementAt(2),
                Article = articles.ElementAt(0),
                CategoryComment = catComments.ElementAt(1),
                CategoryDimension = catDimension.ElementAt(0),
            });

            articleComments.Add(new CommentArticle
            {
                ParentComment = articleComments.ElementAt(4),
                Content = "PODDKOMENTARRR dasdsadsada",
                User = users.ElementAt(2),
                Article = articles.ElementAt(3),
                CategoryComment = catComments.ElementAt(0),
                CategoryDimension = catDimension.ElementAt(0),

            });



            Context.Companies.AddRange(companies);
            Context.Countries.AddRange(countries);
            Context.Townships.AddRange(townships);
            Context.Stickers.AddRange(stickers);
            Context.CategoryDimensions.AddRange(catDimension);
            Context.CategoryComments.AddRange(catComments);
            Context.CategoryDesignArticles.AddRange(catDesignArt);
            Context.NonRegisteredUsers.AddRange(noRegUser);
            Context.UseCaseRoles.AddRange(usecaseRoles);
            
            Context.Articles.AddRange(articles);
            Context.Emotions.AddRange(emotions);

            Context.ArticleImages.AddRange(articleImages);
            Context.CommentArticles.AddRange(articleComments);
            Context.Users.AddRange(users);

            Context.UserCompanies.AddRange(usercomp);


            Context.AllUserUseCases.AddRange(allUsersUseCase);
            ///
            Context.ArticleUserEmotions.AddRange(artUsEmot);


            Context.SaveChanges();

            return StatusCode(201);


        }
        



    }
}
