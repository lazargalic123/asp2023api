﻿using Application.UseCases.PaginationDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.UseCases.Queries.Searches
{
    public class SearchArticlesDto : BasePaginationSearch
    {
        public string? NameArticle { get; set; }
        public string? DescriptionKeyword { get; set; }
        public DateTime? Beggin { get; set; }
        public DateTime? End { get; set; }
        public int? TownshipId { get; set; }
    }

    public class GetArticlesCommentDto
    {
        public int Id { get; set; }
        public string NameArticle { get; set; }
        public string MainPicturePath { get; set; }
        public string Description { get; set; }
        public string? AdditionalDescription { get; set; }
        public string? Quote { get; set; }
        public string? MainContent { get; set; }
        public DateTime Beggin { get; set; }
        public DateTime End { get; set; }

        public AuthorDto Author { get; set; }
        public TownshipDto Township { get; set; }
        public IEnumerable<EmotionDto2> Emotions { get; set; }  = new List<EmotionDto2>();
        public IEnumerable<CommenttDto> Comments { get; set; } = new List<CommenttDto>();

        //Komentari
        //public IEnumerable<Emotion> Emotions { get; set; }  = new List<Emotion>();
    }

    public class CommenttDto
    {
        public int IdComment { get; set; }
        public string Content { get; set; }
        public int? StickerId { get; set; }
        public IEnumerable<CommenttDto> ChildCommentts { get; set; } = new List<CommenttDto>();

    }

    public class EmotionDto2
    {
        public int Id { get; set; }
        public string NazivEmocije { get; set; }
        public string EmotionUser { get; set; }  
        public int EmotionUserId { get; set; }  
    }



    public class TownshipDto
    {
        public int Id { get; set; }
        public string NameTownship { get; set; }
        public string NameCountry { get; set; }
    }

    public class AuthorDto
    {
        public int Id { get; set; }
        public string FistName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}

