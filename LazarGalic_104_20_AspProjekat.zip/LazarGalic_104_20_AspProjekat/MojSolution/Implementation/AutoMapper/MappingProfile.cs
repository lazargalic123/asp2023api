﻿using Application.UseCases.Queries.Searches;
using AutoMapper;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.AutoMapper
{
    public class MappingProfile : Profile
    {

        public MappingProfile()
        {
            CreateMap<Article, GetArticlesCommentDto>()
                .ForMember(dest => dest.NameArticle, opt => opt.MapFrom(src => src.NameArticle))
                .ForMember(dest => dest.MainPicturePath, opt => opt.MapFrom(src => src.MainPicturePath))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.AdditionalDescription, opt => opt.MapFrom(src => src.AdditionalDescription))
                .ForMember(dest => dest.Quote, opt => opt.MapFrom(src => src.Quote))
                .ForMember(dest => dest.MainContent, opt => opt.MapFrom(src => src.MainContent))
                .ForMember(dest => dest.Beggin, opt => opt.MapFrom(src => src.Beggin))
                .ForMember(dest => dest.End, opt => opt.MapFrom(src => src.End))
                .ForMember(dest => dest.Author, opt => opt.MapFrom(src =>
                    new AuthorDto
                    {
                        Id = src.User.Id,
                        Email = src.User.Email,
                        FistName = src.User.FirstName,
                        LastName = src.User.LastName
                    }))
                .ForMember(dest => dest.Township, opt => opt.MapFrom(src =>
                    new TownshipDto
                    {
                        Id = src.TownshipId,
                        NameTownship = src.Township.NameTownship,
                        NameCountry = src.Township.Country.NameCountry
                    }))
                .ForMember(dest => dest.Emotions, opt => opt.MapFrom(src =>
                    new List<EmotionDto2>(src.ArticleUserEmotions.Select(t =>
                        new EmotionDto2
                        {
                            Id = t.EmotionId,
                            EmotionUserId = t.UserId,
                            EmotionUser = t.User.FirstName + " " + t.User.LastName + t.User.Email,
                            NazivEmocije = t.Emotion.NameEmotion
                        }))
                        )
                    )
                 .ForMember(dest => dest.Comments, opt => opt.MapFrom(src =>
                    new List<CommenttDto>(src.CommentArticles.Select(t =>
                        new CommenttDto
                        {
                            IdComment = t.Id,
                            Content = t.Content == null ? "/" : t.Content,
                            StickerId = t.StickerId,
                            ChildCommentts = new List<CommenttDto>(src.CommentArticles.Select(m =>
                                new CommenttDto
                                {
                                    IdComment = m.Id,
                                    Content = m.Content == null ? "/" : m.Content,
                                    StickerId = m.StickerId,
                                }))

                        }))
                   ));
                    




        }

    }
}
