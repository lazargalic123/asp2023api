﻿using Application.UseCases.PaginationDto;
using Application.UseCases.Queries;
using Application.UseCases.Queries.Searches;
using DataAccess;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Implementation.UseCases.Queries.Ef
{
    public class EfGetArticlesQuery : EfUseCase, IGetArticlesQuery
    {
        public EfGetArticlesQuery(Asp2023DbContext context) : base(context)
        {
        }

        public int Id => 22;

        public string Name => "Dohvati artikle";

        public string Description => "";

        public PagedResponse<GetArticlesCommentDto> Execute(SearchArticlesDto search)
        {

            var query = Context.Articles.Where(x => x.DeletedAt == null)
                                        .Include(x => x.CommentArticles)
                                        .ThenInclude(y => y.ChildComments)
                                          .ThenInclude(u => u.Sticker)
                                         .Include(x => x.ArticleUserEmotions)
                                            .ThenInclude(x => x.Emotion)
                                         .Include(x => x.User)
                                         .Include(x => x.Township)
                                            .ThenInclude(x => x.Country)
                                         .AsQueryable();

            if(!string.IsNullOrEmpty(search.NameArticle))
            {
                query = query.Where(x => x.NameArticle.Contains(search.NameArticle));
            }

            if (!string.IsNullOrEmpty(search.DescriptionKeyword))
            {
                query = query.Where(x => x.Description.Contains(search.DescriptionKeyword));
            }
            
            if(search.TownshipId != null && search.TownshipId != 0)
            {
                query = query.Where(x => x.TownshipId==search.TownshipId);
            }

            if (search.End != null && search.End != default(DateTime) )
            {
                query = query.Where(x => x.End  < search.End );
            }
            if (search.Beggin != null && search.Beggin != default(DateTime))
            {
                query = query.Where(x => x.Beggin > search.Beggin);
            }




            if (search.PerPage == null || search.PerPage < 1)
            {
                search.PerPage = 5;
            }

            if (search.Page == null || search.Page < 1)
            {
                search.Page = 1;
            }

            var toSkip = (search.Page.GetValueOrDefault() - 1) * search.PerPage.Value;
            var response = new PagedResponse<GetArticlesCommentDto>();
            response.TotalCount = query.Count();
            response.Data = query.Skip(toSkip).Take(search.PerPage.Value).Select(x => new GetArticlesCommentDto
            {
                Id = x.Id,
                NameArticle = x.NameArticle,
                MainPicturePath = x.MainPicturePath,
                Description = x.Description,
                AdditionalDescription = x.AdditionalDescription,
                Quote = x.Quote,
                MainContent = x.MainContent,
                Beggin = x.Beggin,
                End = x.End,
                Township = new TownshipDto
                {
                    Id = x.Township.Id,
                    NameTownship = x.Township.NameTownship,
                    NameCountry = x.Township.Country.NameCountry
                },
                Author = x.User == null ? new AuthorDto { } : new AuthorDto
                {
                    Id = x.User.Id,
                    FistName = x.User.FirstName,
                    LastName = x.User.LastName,
                    Email = x.User.Email
                },
                Emotions = x.ArticleUserEmotions.Select(y => new EmotionDto2
                {
                    Id = y.EmotionId,
                    NazivEmocije = y.Emotion.NameEmotion,
                    EmotionUser = y.User.FirstName + " " + y.User.LastName,
                    EmotionUserId = y.UserId
                }),
                Comments = x.CommentArticles.Select(y => new CommenttDto
                {
                    IdComment = y.Id,
                    Content = y.Content == null ? "" : y.Content,
                    StickerId = y.StickerId,
                    ChildCommentts = y.ChildComments.Select(z => new CommenttDto
                    {
                        IdComment = z.Id,
                        Content = z.Content == null ? "" : z.Content,
                        StickerId = z.StickerId
                    })
                })

            }).ToList();

            response.CurrentPage = search.Page.GetValueOrDefault();
            response.ItemsPerPage = search.PerPage.GetValueOrDefault();

            return response;


        }
    }
}
