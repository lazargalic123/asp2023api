﻿using Application.UseCases.Queries;
using Application.UseCases.Queries.Searches;
using AutoMapper;
using DataAccess;
using Implementation.AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Implementation.UseCases.Queries.Ef
{
    public class EfIGetOneArticleQuery : EfUseCase, IGetOneArticleQuery
    {

        protected IMapper MyMapper { get; }

        public EfIGetOneArticleQuery(Asp2023DbContext context) : base(context)
        {

            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

             MyMapper = config.CreateMapper();
        }

        public int Id => 26;

        public string Name => "Jedan Artikal";

        public string Description => "";

        public GetArticlesCommentDto Execute(int search)
        {
            var objToFind = Context.Articles.Find(search);
            if(objToFind== null)
            {
                return new GetArticlesCommentDto { };
            }

            var objToMap = Context.Articles.Where(x => x.Id == search)
                                        .Include(x => x.CommentArticles)
                                        .ThenInclude(y => y.ChildComments)
                                          .ThenInclude(u => u.Sticker)
                                         .Include(x => x.ArticleUserEmotions)
                                            .ThenInclude(x=>x.Emotion)
                                         .Include(x => x.User)
                                         .Include(x => x.Township)
                                            .ThenInclude(x => x.Country)
                                         .FirstOrDefault();


            var mapped = MyMapper.Map<GetArticlesCommentDto>(objToFind);

            return mapped;

        }
    }
}
